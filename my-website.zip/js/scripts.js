
// Scripts cho trang web của bạn có thể đặt tại đây

document.addEventListener('DOMContentLoaded', () => {
    console.log('Trang web đã tải xong!');
});
    